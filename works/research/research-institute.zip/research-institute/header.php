<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="keywords" content="Best Multi Speciality Hospital in Madurai" />

    <title>Research Institute</title>

    <link href="<?php bloginfo('template_directory'); ?>/images/favicon.png" rel="icon" type="image/png" />

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
        integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Work+Sans:400,500" rel="stylesheet">
    <link href="<?php bloginfo('template_directory'); ?>/style.css" rel="stylesheet" type="text/css" />
    <link href="<?php bloginfo('template_directory'); ?>/camera-slider/camera.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/slick/slick.css" />

    <link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/slick/slick-theme.css" />

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
        integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
        crossorigin="anonymous"></script>
</head>

<body>
    <header>
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <img src="<?php bloginfo('template_directory'); ?>/images/research_institute_logo.png" alt="Research Institute" class="img-fluid" />
                </div>
                <div class="col-sm-2 offset-2">
                    <div class="header-button">
                        <div class="row">
                            <div class="col-2  pr-0 mr-0">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="col-10 pr-0 mr-0 ml-0">Call Us<br /><b>99409 03106</b></div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-2 px-0">
                    <div class="header-button">
                        <div class="row">
                            <div class="col-2 pr-0 pl-0 mr-0 ml-0">
                                <i class="fa fa-map-marker"></i>
                            </div>
                            <div class="col-10 px-0">Address<br /><b>186, Northveli St., MDU</b></div>
                        </div>
                    </div>
                </div>

                <div class="col-sm-2 pr-0 pl-0">
                    <div class="header-button">
                        <div class="row">
                            <div class="col-2  pr-0 mr-0">
                                <i class="fa fa-clock-o"></i>
                            </div>
                            <div class="col-10">
                                Openning Hours<br />
                                <b>9 - 6:30 MON - SAT</b>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <nav class="navbar navbar-expand-md">
                <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#mainMenu">
                    <span class="navbar-toggler-icon"></span>Menu
                </button>
                <?php
                    wp_nav_menu( array(
                        'theme_location'  => 'header-menu',
                        'depth'	          => 2, // 1 = no dropdowns, 2 = with dropdowns.
                        'container'       => 'div',
                        'container_class' => 'collapse navbar-collapse',
                        'container_id'    => 'mainMenu',
                        'menu_class'      => 'navbar-nav',
                        'fallback_cb'     => 'WP_Bootstrap_Navwalker::fallback',
                        'walker'          => new WP_Bootstrap_Navwalker(),
                    ) );
                ?>
            </nav>
        </div>
    </header>