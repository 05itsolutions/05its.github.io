<?php
    get_header();
    while (have_posts()) {
        the_post();
?>

    <div class="container my-4 slide-ri">
        <?php
            $img_url=get_the_post_thumbnail_url();
            if($img_url!=''){
        ?>
            <img src="<?php echo $img_url; ?>" alt="<?php the_title(); ?>" class="img-fluid w-100" />
        <?php 
            } 
            else {
        ?>
        <div class="slider border">
            <div data-thumb="<?php bloginfo('template_directory'); ?>/images/header_image_dream.jpg" data-src="<?php bloginfo('template_directory'); ?>/images/header_image_dream.jpg"></div>
            <div data-thumb="<?php bloginfo('template_directory'); ?>/images/header_image_career.jpg" data-src="<?php bloginfo('template_directory'); ?>/images/header_image_career.jpg"></div>
            <div data-thumb="<?php bloginfo('template_directory'); ?>/images/header_image_mobile.jpg" data-src="<?php bloginfo('template_directory'); ?>/images/header_image_mobile.jpg"></div>
            <div data-thumb="<?php bloginfo('template_directory'); ?>/images/header_image_webdesign.jpg" data-src="<?php bloginfo('template_directory'); ?>/images/header_image_webdesign.jpg"></div>
            <div data-thumb="<?php bloginfo('template_directory'); ?>/images/header_image_electronics.jpg" data-src="<?php bloginfo('template_directory'); ?>/images/header_image_electronics.jpg"></div>
        </div>
        <?php } ?>
    </div>

    <div class="container py-2 my-4">
        <h1 class="mt-5 mb-4"><?php the_title();?></h1>
        <?php the_content();?>
    </div>

<?php
    }
    get_footer();
 ?>