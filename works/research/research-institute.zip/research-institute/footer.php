<footer class="w-100 py-5">
        <div class="container">
            <div class="row">
                <div class="col-sm-3 px-3">
                    <img src="<?php bloginfo('template_directory'); ?>/images/research-icon.png" alt="Research Institute" class="d-block" />
                    <p class="text-white">Research Institute creates a drastic change in one’s career growth for their development field and fulfills their client’s requirements successful.</p>
                </div>

                <div class="col-sm-3 px-3">
                    <h3 class="text-white text-left">Certificates</h3>
                    <div class="row">
                        <div class="col-6">
                            <img src="<?php bloginfo('template_directory'); ?>/images/certificate-nasscom-member.png" alt="" class="w-100 img-fluid"/>
                        </div>
                        <div class="col-6">
                            <img src="<?php bloginfo('template_directory'); ?>/images/certificate-iso.png" alt="" class="w-100 img-fluid"/>
                        </div>
                        <div class="col-6">
                            <img src="<?php bloginfo('template_directory'); ?>/images/certificate-aiao-bar.png" alt="" class="w-100 img-fluid"/>
                        </div>
                        <div class="col-6">
                            <img src="<?php bloginfo('template_directory'); ?>/images/certificate-digital-india.png" alt="" class="w-100 img-fluid"/>
                        </div>
                    </div>
                </div>

                <div class="col-sm-3 px-3">
                    <h3 class="text-white text-left">Our Benefits</h3>
                    <ul>
                        <li>Novel Work</li>
                        <li>In-depth Study</li>
                        <li>Plagiarism</li>
                        <li>Certified Team</li>
                        <li>Trustworthy</li>
                        <li>Affordable Cost</li>
                    </ul>
                </div>

                <div class="col-sm-3 px-3">
                    <h3 class="text-white text-left">Our Branches</h3>
                    <ul>
                        <li>Mumbai</li>
                        <li>Pune</li>
                        <li>Trivandrum</li>
                        <li>Chennai</li>
                        <li>Madurai</li>
                    </ul>

                </div>
            </div>
        </div>
    </footer>

    <script src="<?php bloginfo('template_directory'); ?>/scripts/jquery.waypoints.min.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/scripts/jquery.countup.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/camera-slider/jquery.easing.1.3.js"></script>
    <script src="<?php bloginfo('template_directory'); ?>/camera-slider/camera.min.js"></script>
    <script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/slick/slick.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('.counter').countUp();

            $('.autoplay').slick({
                slidesToShow: 6,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2000,
            });

            $('.slider').camera({
                loader: true,
                navigation: true,
                autoPlay: true,
                time: 4000,
                playPause: false,
                pagination: false,
                thumbnails: false,
                overlayer: false,
                hover: false,
                height: '35%',
            });
        });
    </script>
</body>

</html>