<?php
get_header();
?>

    <div class="container my-4 slide-ri">
        <div class="slider border">
            <div data-thumb="<?php bloginfo('template_directory'); ?>/images/header_image_dream.jpg" data-src="<?php bloginfo('template_directory'); ?>/images/header_image_dream.jpg"></div>
            <div data-thumb="<?php bloginfo('template_directory'); ?>/images/header_image_career.jpg" data-src="<?php bloginfo('template_directory'); ?>/images/header_image_career.jpg"></div>
            <div data-thumb="<?php bloginfo('template_directory'); ?>/images/header_image_mobile.jpg" data-src="<?php bloginfo('template_directory'); ?>/images/header_image_mobile.jpg"></div>
            <div data-thumb="<?php bloginfo('template_directory'); ?>/images/header_image_webdesign.jpg" data-src="<?php bloginfo('template_directory'); ?>/images/header_image_webdesign.jpg"></div>
            <div data-thumb="<?php bloginfo('template_directory'); ?>/images/header_image_electronics.jpg" data-src="<?php bloginfo('template_directory'); ?>/images/header_image_electronics.jpg"></div>
        </div>
    </div>

    <div class="container py-2 my-4">
        <h1 class="mt-5 mb-4">Our Features</h1>

        <div class="row">
            <div class="col-sm-4 p-2 px-5">
                <div class="border shadow-sm p-1 bg-feature">
                    <div class="border py-5 p-2">
                        <h5 class="my-2">On-Time Service</h5>
                        <img src="<?php bloginfo('template_directory'); ?>/images/on-time-service.png" class="d-block mx-auto" />
                        <<p class="text-center mt-0">We have high experienced professional experts and technical developers to ensure work for clients with delivered projects and research work in on-time.</p>
                        <p class="text-center mb-0"><a href="#" class="btn btn-ri">Read More</a></p>
                    </div>
                </div>
            </div>

            <div class="col-sm-4 p-2 px-5">
                <div class="border rounded shadow-sm p-1 bg-feature">
                    <div class="border py-5 p-2">
                        <h5 class="my-2">24/7 Support</h5>
                        <img src="<?php bloginfo('template_directory'); ?>/images/24-7-support.png" class="d-block mx-auto" />
                        <p class="text-center mt-0">We provide 24/7 support service for customers with email-based and chat communication, phone calls, and face to face direct conversation.</p>
                        <p class="text-center mb-0"><a href="#" class="btn btn-ri">Read More</a></p>
                    </div>
                </div>
            </div>

            <div class="col-sm-4 p-2 px-5">
                <div class="border rounded shadow-sm p-1 bg-feature">
                    <div class="border py-5 p-2">
                        <h5 class="my-2">Work Confidential</h5>
                        <img src="<?php bloginfo('template_directory'); ?>/images/work-confidential.png" class="d-block mx-auto" />
                        <p class="text-center mt-0">In our service, we provide confidentiality support to our customers. We maintain each and every students/scholars information to be in safe mode.</p>
                        <p class="text-center mb-0"><a href="#" class="btn btn-ri">Read More</a></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-5">
            <div class="col-sm-4 p-2 px-5">
                <div class="border shadow-sm p-1 bg-feature">
                    <div class="border py-5 p-2">
                        <h5 class="my-2">Cost Affordability</h5>
                        <img src="<?php bloginfo('template_directory'); ?>/images/cost-affordability.png" class="d-block mx-auto" />
                        <p class="text-center mt-0">Our vast experience experts provide high value, inexpensive, and cost-effective support for various field with different domains of projects/research work.</p>
                        <p class="text-center mb-0"><a href="#" class="btn btn-ri">Read More</a></p>
                    </div>
                </div>
            </div>

            <div class="col-sm-4 p-2 px-5">
                <div class="border shadow-sm p-1 bg-feature">
                    <div class="border py-5 p-2">
                        <h5 class="my-2">High Quality</h5>
                        <img src="<?php bloginfo('template_directory'); ?>/images/high-quality.png" class="d-block mx-auto" />
                        <p class="text-center mt-0">We have domain-wise specialists to provide unique work to quantify the degree for customer satisfaction with ensured quality, right tools, and quality monitor.</p>
                        <p class="text-center mb-0"><a href="#" class="btn btn-ri">Read More</a></p>
                    </div>
                </div>
            </div>

            <div class="col-sm-4 p-2 px-5">
                <div class="border shadow-sm p-1 bg-feature">
                    <div class="border py-5 p-2">
                        <h5 class="my-2">Reliable &amp; Trust</h5>
                        <img src="<?php bloginfo('template_directory'); ?>/images/reliable-trust.png" alt="Reliable and Trust" class="d-block mx-auto" />
                        <p class="text-center mt-0">We offer quick, reliable and accurate guidance with optimistic research/projects help to take a great journey for students and scholars in their respective field.</p>
                        <p class="text-center mb-0"><a href="#" class="btn btn-ri">Read More</a></p>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="w-100 py-5 shadow bg-ri">
        <div class="container">
            <h1 class="text-white">Our Stats</h1>
            <div class="row">
                <div class="col-sm-3 stats text-center">
                    <i class="fa fa-user-o m-3 p-2">&nbsp;</i>
                    <h3><span class="counter" data-counter-time="2000" data-counter-delay="10">100</span></h3>
                    <h5>Employees</h5>
                </div>
                <div class="col-sm-3 stats text-center">
                    <i class="fa fa-thumbs-o-up m-3 p-2">&nbsp;</i>
                    <h3><span class="counter" data-counter-time="2000" data-counter-delay="10">7000</span></h3>
                    <h5>Success Stories</h5>
                </div>
                <div class="col-sm-3 stats text-center">
                    <i class="fa fa-file-o m-3 p-2">&nbsp;</i>
                    <h3><span class="counter" data-counter-time="2000" data-counter-delay="10">2500</span></h3>
                    <h5>Publications<br />(SCI, ISI, Scopus)</h5>
                </div>
                <div class="col-sm-3 stats text-center">
                    <i class="fa fa-laptop m-3 p-2">&nbsp;</i>
                    <h3><span class="counter" data-counter-time="2000" data-counter-delay="10">4600</span></h3>
                    <h5>Projects</h5>
                </div>
            </div>
        </div>
    </div>

    <div class="container py-5">
        <h1 class="mt-3 mb-4">Our Services</h1>
        <div class="row">
            <div class="col-sm-6 my-1 p-3">
                <img src="<?php bloginfo('template_directory'); ?>/images/service_research.jpg" alt="" class="img-fluid" />
                <div class="w-100 p-2 px-4 border">
                    <h4 class="mt-4 mb-3 text-left">Research</h4>
                    <p>Our Research is well-defined as a cautious consideration of study on the subject of a particular concern or a research problem using scientific methods.</p>
                    <a href="#" class="btn btn-ri mb-3">Read More</a>
                </div>
            </div>

            <div class="col-sm-6 my-1 p-3">

                <img src="<?php bloginfo('template_directory'); ?>/images/service_projects.jpg" alt="" class="img-fluid" />
                <div class="w-100 p-2 px-4 border">
                    <h4 class="mt-4 mb-3 text-left">Projects</h4>
                    <p>We have marvelous mentors in support for overall concern for research implementation projects for scholars and students in their respective field.</p>
                    <a href="#" class="btn btn-ri mb-3">Read More</a>
                </div>
            </div>

            <div class="col-sm-6 my-1 p-3">

                <img src="<?php bloginfo('template_directory'); ?>/images/service_software_development.jpg" alt="" class="img-fluid" />
                <div class="w-100 p-2 px-4 border">
                    <h4 class="mt-4 mb-3 text-left">Software Development</h4>
                    <p>Our software development is a high-quality service to provide solutions for client inadequacy. We offer scalable and robust software development services across various platforms.</p>
                    <a href="#" class="btn btn-ri mb-3">Read More</a>
                </div>
            </div>

            <div class="col-sm-6 my-1 p-3">

                <img src="<?php bloginfo('template_directory'); ?>/images/service_web_development.jpg" alt="" class="img-fluid" />
                <div class="w-100 p-2 px-4 border">
                    <h4 class="mt-4 mb-3 text-left">Web Development</h4>
                    <p>Our universal prominent web development service started with our specialists to provide for scholars / students (PhD /MS) needs of excellence and standard guidance from overall world.</p>
                    <a href="#" class="btn btn-ri mb-3">Read More</a>
                </div>
            </div>

            <div class="col-sm-6 my-1 p-3">

                <img src="<?php bloginfo('template_directory'); ?>/images/service_electronics.jpg" alt="" class="img-fluid" />
                <div class="w-100 p-2 px-4 border">
                    <h4 class="mt-4 mb-3 text-left">Electronic Products</h4>
                    <p>An electronics product is the topmost service started with our expert’s ground-breaking ideas to provide guidance for education learners requisite.</p>
                    <a href="#" class="btn btn-ri mb-3">Read More</a>
                </div>
            </div>

            <div class="col-sm-6 my-1 p-3">

                <img src="<?php bloginfo('template_directory'); ?>/images/service_mobile.jpg" alt="" class="img-fluid" />
                <div class="w-100 p-2 px-4 border">
                    <h4 class="mt-4 mb-3 text-left">Mobile App Development</h4>
                    <p>Mobile app development is our fabulous service started with wonderful expert’s knowledge to provide high quality standard mobile app service for any category.</p>
                    <a href="#" class="btn btn-ri mb-3">Read More</a>
                </div>
            </div>
        </div>
    </div>

    <div class="w-100 py-5 bg-ri">
        <div class="container">
            <h1 class="text-white">What Our Clients Say</h1>
            <div class="row">
                <div class="col-sm-6 p-3">
                    <div class="border rounded bg-ri-light p-3">
                        <img src="<?php bloginfo('template_directory'); ?>/images/client1.jpg" alt="Testimonial"
                            class="rounded-circle img-fluid w-25 d-block mx-auto border" />
                        <h4 class="my-2">Mr. Ritambhra</h4>
                        <p class="font-italic">Are you looking for any research center? To build your research/project work in excellence and help your dreams come to permit. There is only one option "Research Institute" there is no one in substitute.</p>
                    </div>
                </div>

                <div class="col-sm-6 p-3">
                    <div class="border rounded bg-ri-light p-3">
                        <img src="<?php bloginfo('template_directory'); ?>/images/client2.jpg" alt="Testimonial"
                            class="rounded-circle img-fluid w-25 d-block mx-auto border" />
                        <h4 class="my-2">Mrs. Sumanta Basu</h4>
                        <p class="font-italic">I’m happy with their assistance. Thanks for helping and supporting us very well. This institute provides wowed me in each and every way of possible. These services provide to complete each step with extra care for program/code/pseudo code, etc.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container py-5">
        <h1 class="my-4">Our Latest Projects</h1>
        <div id="projects" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
            <div class="carousel-item active">
                    <div class="row">
                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/1-Vehicle-Theft-System.jpg" alt="Vehicle Theft System" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Vehicle Theft System</h4>
                            </div>
                        </div>

                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/2-Unshakable-Secure-Home.jpg" alt="Unshakable Secure Home" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Unshakable Secure Home</h4>
                            </div>
                        </div>

                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/3-Weather-Reporting-System.jpg" alt="Weather Reporting System" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Weather Reporting System</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="carousel-item">
                    <div class="row">
                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/4-Human-Resembling-Dancing-Robot.jpg" alt="Human Resembling Dancing Robot" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Human Resembling Dancing Robot</h4>
                            </div>
                        </div>

                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/5-Automatic-Control-System.jpg" alt="Automatic Control System" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Automatic Control System</h4>
                            </div>
                        </div>

                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/6-Military-Robot.jpg" alt="Military Robot" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Military Robot</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="carousel-item">
                    <div class="row">
                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/7-Speedy-Motor-Monitoring.jpg" alt="Speedy Motor Monitoring" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Speedy Motor Monitoring</h4>
                            </div>
                        </div>

                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/8-Approaching-Target-Detection.jpg" alt="Approaching Target Detection" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Approaching Target Detection</h4>
                            </div>
                        </div>

                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/9-Electricity aware-Smart-Home.jpg" alt="Electricity aware Smart Home" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Electricity aware Smart Home</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="carousel-item">
                    <div class="row">
                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/10-Farmer-Friendly-Robot.jpg" alt="Farmer Friendly Robot" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Farmer Friendly Robot</h4>
                            </div>
                        </div>

                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/11-Solar-Power-Generator.jpg" alt="Solar Power Generator" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Solar Power Generator</h4>
                            </div>
                        </div>

                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/12-Border-Patrolling-Robot.jpg" alt="Border Patrolling Robot" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Border Patrolling Robot</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="carousel-item">
                    <div class="row">
                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/13-Vehicular-Emergency-Services-System.jpg" alt="Vehicular Emergency Services System" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Vehicular Emergency Services System</h4>
                            </div>
                        </div>

                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/14-Gas-Outflow-Discovery-System.jpg" alt="Gas Outflow Discovery System" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Gas Outflow Discovery System</h4>
                            </div>
                        </div>

                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/15-Speech-Controlled-Devices.jpg" alt="Speech Controlled Devices" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Speech Controlled Devices</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="carousel-item">
                    <div class="row">
                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/16-Event-Management-System.jpg" alt="Event Management System" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Event Management System</h4>
                            </div>
                        </div>

                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/17-Surveilling-Housh-ld-Devices.jpg" alt="SurveillingHoushold Devices" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Surveilling Houshold Devices</h4>
                            </div>
                        </div>

                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/18-Cable-Failure-Identification.jpg" alt="Cable Failure Identification" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Cable Failure Identification</h4>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="carousel-item">
                    <div class="row">
                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/19-Industrial-Machinery-Controls.jpg" alt="Industrial Machinery Controls" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Industrial Machinery Controls</h4>
                            </div>
                        </div>

                        <div class="col-sm-4 mb-5">
                            <div class="shadow border">
                                <img src="<?php bloginfo('template_directory'); ?>/images/20-Smart-Electricity-Billing.png" alt="Smart Electricity Billing" class="w-100 img-fluid" />
                                <h4 class="pt-4 p-3">Smart Electricity Billing</h4>
                            </div>
                        </div>

                        <div class="col-sm-4 mb-5">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>

    <div class="row no-gutters">
        <div class="col-sm-6">
                <iframe src="https://www.google.com/maps/embed?pb=!1m12!1m8!1m3!1d34835.80466499028!2d78.10322446475656!3d9.921966156549567!3m2!1i1024!2i768!4f13.1!2m1!1sresearch+institute+madurai!5e0!3m2!1sen!2sin!4v1555775958384!5m2!1sen!2sin" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
        <div class="col-sm-6 bg-light p-5">
            <h2>Get in Touch</h2>
            <form>
                <input type="text" placeholder="Name" class="form-control my-3" />
                <input type="text" placeholder="Phone" class="form-control my-3" />
                <textarea placeholder="Message" class="form-control my-3"></textarea>
                <input type="button" class="btn btn-ri d-block mx-auto" value="Submit" />
            </form>
        </div>
    </div>

    <div class="bgcompany">
        <div class="autoplay">
            <img src="<?php bloginfo('template_directory'); ?>/images/client_agri_digital.png" alt="">
            <img src="<?php bloginfo('template_directory'); ?>/images/client_doc_sign.png" alt="">
            <img src="<?php bloginfo('template_directory'); ?>/images/client_gosite.png" alt="">
            <img src="<?php bloginfo('template_directory'); ?>/images/client_university_carolina.png" alt="">
            <img src="<?php bloginfo('template_directory'); ?>/images/client_net_app.png" alt="">
            <img src="<?php bloginfo('template_directory'); ?>/images/client_shivaji_university.png" alt="">
            <img src="<?php bloginfo('template_directory'); ?>/images/client_solista.png" alt="">
            <img src="<?php bloginfo('template_directory'); ?>/images/client_climson_university.png" alt="">
            <img src="<?php bloginfo('template_directory'); ?>/images/client_grid_gain.png" alt="">
        </div>
    </div>

<?php
    get_footer();
?>