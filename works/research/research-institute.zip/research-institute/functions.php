<?php
add_theme_support('post-thumbnails'); 

require_once get_template_directory() . '/class-wp-bootstrap-navwalker.php';

add_theme_support('menus');
register_nav_menus(array('header-menu'=>__('Header Menu')));
?>